function submit() {
    // 데이터타입과 연산자
    const datatype1 = document.getElementById("datatype__1").value;
    const datatype2 = document.getElementById("datatype__2").value;
    const datatype3 = document.getElementById("datatype__3").value;

    // 조건문
    const condit1 = document.getElementById("tnf__1").value;
    const condit2 = document.getElementById("tnf__2").value.toLowerCase();
    const condit3 = document.getElementById("tnf__3").value;

    // 반복문
    const loop1 = document.getElementById("forloop__1").value.toLowerCase();
    const loop2 = document.getElementById("forloop__2").value;

    // 수학객체
    const mathobj1 = document.getElementById("mathobj__1").value.toLowerCase();
    const mathobj2 = document.getElementById("mathobj__2").value.toLowerCase();
    const mathobj3 = document.getElementById("mathobj__3").value.toLowerCase();
    const mathobj4 = document.getElementById("mathobj__4").value.toLowerCase();
    const mathobj5 = document.getElementById("mathobj__5").value.toLowerCase();
    const mathobj6 = document.getElementById("mathobj__6").value.toLowerCase();

    //DOM
    const dom1 = document.getElementById("dom__1").value;
    const dom2 = document.getElementById("dom__2").value;
    const dom3 = document.getElementById("dom__3").value;
    const dom4 = document.getElementById("dom__4").value;

    const ans5_4 = "value"
    const ans5_3 = "code"
    const ans5_2 = "getElementById"
    const ans5_1 = "document"
    const ans4_6 = "floor"
    const ans4_5 = "ceil"
    const ans4_4 = "round"
    const ans4_3 = "random"
    const ans4_2 = "min"
    const ans4_1 = "max"
    const ans3_2 = "[count]"
    const ans3_1 = "array.length"
    const ans2_3 = "위험"
    const ans2_2 = "else"
    const ans2_1 = ">="
    const ans1_3 = "91736540"
    const ans1_2 = "%"
    const ans1_1 = "문자"

    let a1, a2, a3, a4, a5, a6

    if(datatype1 !== ans1_1 || datatype2 !== ans1_2 || datatype3 !==ans1_3) {
        document.getElementById("error_datatype").innerText = "정답이 아닙니다"
        document.getElementById("error_datatype").style.color = "red"
        document.getElementById("error_datatype").style.borderBottomColor = "red"
        document.getElementById("q_datatype").style.boxShadow = "7px 7px 39px red"
        a1 = false;
    } else {
        console.log("데이터타입과 연산자 완료")
        document.getElementById("error_datatype").innerText = "정답입니다"
        document.getElementById("error_datatype").style.color = "blue"
        document.getElementById("error_datatype").style.borderBottomColor = "blue"
        document.getElementById("q_datatype").style.boxShadow = "7px 7px 39px blue"
        a1 = true;
    }

    if(condit1 !== ans2_1 || condit2 !== ans2_2) {
        document.getElementById("error_condit1").innerText = "정답이 아닙니다"
        document.getElementById("error_condit1").style.color = "red"
        document.getElementById("error_condit1").style.borderBottomColor = "red"
        document.getElementById("q_condit1").style.boxShadow = "7px 7px 39px red"
        a2 = false;
    } else {
        console.log("조건문-1 완료")
        document.getElementById("error_condit1").innerText = "정답입니다"
        document.getElementById("error_condit1").style.color = "blue"
        document.getElementById("error_condit1").style.borderBottomColor = "blue"
        document.getElementById("q_condit1").style.boxShadow = "7px 7px 39px blue"
        a2 = true;
    }

    if(condit3 !== ans2_3) {
        document.getElementById("error_condit2").innerText = "정답이 아닙니다"
        document.getElementById("error_condit2").style.color = "red"
        document.getElementById("error_condit2").style.borderBottomColor = "red"
        document.getElementById("q_condit2").style.boxShadow = "7px 7px 39px red"
        a3 = false;
    } else {
        console.log("조건문-2 완료")
        document.getElementById("error_condit2").innerText = "정답입니다"
        document.getElementById("error_condit2").style.color = "blue"
        document.getElementById("error_condit2").style.borderBottomColor = "blue"
        document.getElementById("q_condit2").style.boxShadow = "7px 7px 39px blue"
        a3 = true;
    }

    if(loop1 !== ans3_1 || loop2 !== ans3_2) {
        document.getElementById("error_forloop").innerText = "정답이 아닙니다"
        document.getElementById("error_forloop").style.color = "red"
        document.getElementById("error_forloop").style.borderBottomColor = "red"
        document.getElementById("q_forloop").style.boxShadow = "7px 7px 39px red"
        a4 = false;
    } else {
        console.log("반복문 완료")
        document.getElementById("error_forloop").innerText = "정답입니다"
        document.getElementById("error_forloop").style.color = "blue"
        document.getElementById("error_forloop").style.borderBottomColor = "blue"
        document.getElementById("q_forloop").style.boxShadow = "7px 7px 39px blue"
        a4 = true;
    }

    if(mathobj1 !== ans4_1 || mathobj2 !== ans4_2 || mathobj3 !== ans4_3 || mathobj4 !== ans4_4 || mathobj5 !== ans4_5 || mathobj6 !== ans4_6) {
        document.getElementById("error_mathobj").innerText = "정답이 아닙니다"
        document.getElementById("error_mathobj").style.color = "red"
        document.getElementById("error_mathobj").style.borderBottomColor = "red"
        document.getElementById("q_mathobj").style.boxShadow = "7px 7px 39px red"
        a5 = false;
    } else {
        console.log("수학객체 완료")
        document.getElementById("error_mathobj").innerText = "정답입니다"
        document.getElementById("error_mathobj").style.color = "blue"
        document.getElementById("error_mathobj").style.borderBottomColor = "blue"
        document.getElementById("q_mathobj").style.boxShadow = "7px 7px 39px blue"
        a5 = true;
    }

    if(dom1 !== ans5_1 || dom2 !== ans5_2 || dom3 !== ans5_3 || dom4 !== ans5_4) {
        document.getElementById("error_dom").innerText = "정답이 아닙니다"
        document.getElementById("error_dom").style.color = "red"
        document.getElementById("error_dom").style.borderBottomColor = "red"
        document.getElementById("q_dom").style.boxShadow = "7px 7px 39px red"
        a6 = false;
    } else {
        console.log("DOM 완료")
        document.getElementById("error_dom").innerText = "정답입니다"
        document.getElementById("error_dom").style.color = "blue"
        document.getElementById("error_dom").style.borderBottomColor = "blue"
        document.getElementById("q_dom").style.boxShadow = "7px 7px 39px blue"
        a6 = true;
    }

    if(a1 === false || a2 === false || a3 === false || a4 === false || a5 === false || a6 === false) {
        window.scrollTo(0, 0)
        alert("틀린 문제가 있습니다")
    } else {
        alert("축하합니다! 문제를 모두 풀었습니다")
    }

}